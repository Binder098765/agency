# Revento AI site: setup

Files: index.html, trades.html, law-firms.html, styles.css, main.js, apps-script.gs

## 1. Save form answers to a Google Sheet (5 minutes)
1. Create a new Google Sheet (name it "Revento leads").
2. Open Extensions > Apps Script. Delete the sample code and paste in everything from apps-script.gs. Save.
3. Optional: put your email in NOTIFY_EMAIL at the top to get an email for each lead.
4. Click Deploy > New deployment > type "Web app". Set "Execute as" to Me and "Who has access" to Anyone. Deploy and approve the permissions.
5. Copy the Web app URL (it ends in /exec).
6. Open main.js and paste it into appsScriptUrl: '' at the top. Save.
7. Test: open the web app URL in a browser. You should see {"ok":true,...}. Then submit the form on your site and check the "Leads" tab.

The sheet adds a Priority column: A+ ($2,500+), A ($1,000 to $2,500), B ($500 to $1,000), C (under $500, flagged). Low budget leads can still book, as you chose.

## 2. Calendly
The form hands people to your Calendly event inline after they submit. The link is calendlyUrl at the top of main.js. If you change the event, change it there.

## 3. Free pilot banner
pilotSpots at the top of main.js controls the "Taking 2 free pilot spots" banner. Set it to 1 when one is taken, and 0 to hide it.

## 4. Publish
Upload the whole folder to wherever reventoai.co is hosted, replacing the old index.html. Keep all files in the same folder.

## 5. Before you go live
- Replace the example phone numbers in the chat mockups only if you want; they use reserved fake numbers on purpose.
- Add a short privacy note or page if you plan to collect leads at volume. I am not a lawyer, so check Canada's anti-spam and privacy rules.
- Add real testimonials and results only once you have them, with permission.
