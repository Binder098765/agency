/* ============================================================
   Revento AI site settings. Edit these three values only.
   ============================================================ */
const CONFIG = {
  // Your Calendly event link (shown after the form is submitted)
  calendlyUrl: 'https://calendly.com/benayoune19/meeting-reventoai',
  // Paste the Google Apps Script web app URL here (see SETUP.md). Leave empty to skip saving.
  appsScriptUrl: '',
  // Free pilot spots left. Set to 0 to hide the banner.
  pilotSpots: 2
};

/* ---------- Pilot banner ---------- */
(function pilotBanner() {
  const el = document.getElementById('pilot-banner');
  if (!el) return;
  if (CONFIG.pilotSpots > 0) {
    const n = CONFIG.pilotSpots;
    el.querySelector('[data-spots]').textContent =
      n + (n === 1 ? ' free pilot spot' : ' free pilot spots');
    el.hidden = false;
  }
})();

/* ---------- Custom cursor (mouse users only) ---------- */
(function cursor() {
  if (!window.matchMedia('(hover: hover) and (pointer: fine)').matches) return;
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  const dot = document.getElementById('cursor');
  const ring = document.getElementById('cursor-ring');
  if (!dot || !ring) return;
  document.body.classList.add('has-cursor');
  let mx = 0, my = 0, rx = 0, ry = 0;
  document.addEventListener('mousemove', function (e) {
    mx = e.clientX; my = e.clientY;
    dot.style.left = mx + 'px'; dot.style.top = my + 'px';
  });
  (function loop() {
    rx += (mx - rx) * 0.12; ry += (my - ry) * 0.12;
    ring.style.left = rx + 'px'; ring.style.top = ry + 'px';
    requestAnimationFrame(loop);
  })();
  document.querySelectorAll('a,button,.svc,.who-card,summary').forEach(function (el) {
    el.addEventListener('mouseenter', function () { ring.style.width = '48px'; ring.style.height = '48px'; ring.style.borderColor = 'rgba(200,245,99,0.7)'; });
    el.addEventListener('mouseleave', function () { ring.style.width = '32px'; ring.style.height = '32px'; ring.style.borderColor = 'rgba(200,245,99,0.4)'; });
  });
})();

/* ---------- Qualification form -> Google Sheet -> Calendly ---------- */
(function leadForm() {
  const form = document.getElementById('lead-form');
  if (!form) return;
  const booking = document.getElementById('booking');
  const errorBox = document.getElementById('form-error');
  const submitBtn = form.querySelector('button[type="submit"]');

  // Preselect the business type on niche pages
  const niche = form.dataset.niche;
  if (niche && form.elements.businessType) form.elements.businessType.value = niche;

  function clean(v, max) {
    return String(v || '').replace(/\s+/g, ' ').trim().slice(0, max || 300);
  }

  function loadCalendly(name, email) {
    const params = new URLSearchParams({
      hide_gdpr_banner: '1',
      background_color: '0d0d0f',
      text_color: 'f0f0ee',
      primary_color: 'c8f563'
    });
    if (name) params.set('name', name);
    if (email) params.set('email', email);
    const holder = document.getElementById('calendly-holder');
    holder.innerHTML = '';
    const div = document.createElement('div');
    div.className = 'calendly-inline-widget';
    div.setAttribute('data-url', CONFIG.calendlyUrl + '?' + params.toString());
    holder.appendChild(div);
    if (!document.getElementById('calendly-script')) {
      const s = document.createElement('script');
      s.id = 'calendly-script';
      s.src = 'https://assets.calendly.com/assets/external/widget.js';
      s.async = true;
      document.body.appendChild(s);
    } else if (window.Calendly && window.Calendly.initInlineWidgets) {
      window.Calendly.initInlineWidgets();
    }
  }

  function showBooking(name, email) {
    form.hidden = true;
    booking.hidden = false;
    loadCalendly(name, email);
    booking.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  form.addEventListener('submit', async function (e) {
    e.preventDefault();
    errorBox.textContent = '';
    if (!form.reportValidity()) return;
    const f = form.elements;
    if (f.website && f.website.value) return; // honeypot: bots fill this in

    const data = {
      name: clean(f.name.value, 100),
      email: clean(f.email.value, 200),
      phone: clean(f.phone.value, 40),
      business: clean(f.business.value, 150),
      businessType: clean(f.businessType.value, 60),
      teamSize: clean(f.teamSize.value, 40),
      callsPerWeek: clean(f.callsPerWeek.value, 40),
      missed: clean(f.missed.value, 40),
      jobValue: clean(f.jobValue.value, 40),
      tools: clean(f.tools.value, 200),
      budget: clean(form.querySelector('input[name="budget"]:checked').value, 40),
      consent: f.consent.checked,
      page: location.pathname
    };

    submitBtn.disabled = true;
    submitBtn.textContent = 'Sending...';
    try {
      if (CONFIG.appsScriptUrl) {
        await fetch(CONFIG.appsScriptUrl, {
          method: 'POST',
          mode: 'no-cors',
          headers: { 'Content-Type': 'text/plain;charset=utf-8' },
          body: JSON.stringify(data)
        });
      } else {
        console.warn('Revento AI: appsScriptUrl is empty, so this answer was not saved.', data);
      }
    } catch (err) {
      // Never block a real lead from booking because saving failed
      console.error('Could not save the answers', err);
    }
    submitBtn.disabled = false;
    submitBtn.textContent = 'Continue to book a time';
    showBooking(data.name, data.email);
  });
})();
