/**
 * Revento AI lead capture.
 * Paste this into Extensions > Apps Script inside a Google Sheet, then deploy as a web app.
 * Full steps are in SETUP.md.
 */

// Optional: set an email address to get a notification for every new lead. Leave '' for none.
const NOTIFY_EMAIL = '';
const SHEET_NAME = 'Leads';

const HEADERS = [
  'Received', 'Name', 'Email', 'Phone', 'Business', 'Business type', 'Team size',
  'Calls or enquiries per week', 'Missed or slow', 'Average job or client value',
  'Current tools', 'Monthly budget', 'Priority', 'Page', 'Consent'
];

function doPost(e) {
  try {
    const d = JSON.parse(e.postData.contents);
    const sheet = getSheet_();
    const priority = priority_(d.budget);
    sheet.appendRow([
      new Date(),
      safe_(d.name), safe_(d.email), safe_(d.phone), safe_(d.business),
      safe_(d.businessType), safe_(d.teamSize), safe_(d.callsPerWeek), safe_(d.missed),
      safe_(d.jobValue), safe_(d.tools), safe_(d.budget), priority, safe_(d.page),
      d.consent ? 'yes' : 'no'
    ]);
    if (NOTIFY_EMAIL) {
      MailApp.sendEmail(
        NOTIFY_EMAIL,
        'New Revento AI lead: ' + safe_(d.business) + ' (' + priority + ')',
        'Name: ' + safe_(d.name) + '\nEmail: ' + safe_(d.email) + '\nPhone: ' + safe_(d.phone) +
        '\nBusiness: ' + safe_(d.business) + ' / ' + safe_(d.businessType) +
        '\nBudget: ' + safe_(d.budget) + '\nCalls per week: ' + safe_(d.callsPerWeek) +
        '\nMissed or slow: ' + safe_(d.missed) + '\nAverage value: ' + safe_(d.jobValue) +
        '\nTools: ' + safe_(d.tools)
      );
    }
    return json_({ ok: true });
  } catch (err) {
    return json_({ ok: false, error: String(err) });
  }
}

// Lets you open the web app URL in a browser to check that it is live.
function doGet() {
  return json_({ ok: true, service: 'Revento AI lead capture' });
}

function priority_(budget) {
  switch (budget) {
    case '2500-plus': return 'A+';
    case '1000-2500': return 'A';
    case '500-1000': return 'B';
    case 'under-500': return 'C (low budget, flagged)';
    default: return '';
  }
}

function getSheet_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sh = ss.getSheetByName(SHEET_NAME);
  if (!sh) {
    sh = ss.insertSheet(SHEET_NAME);
    sh.appendRow(HEADERS);
    sh.setFrozenRows(1);
  }
  return sh;
}

// Stops values that start with = + - @ from running as spreadsheet formulas
function safe_(v) {
  const s = String(v === undefined || v === null ? '' : v).slice(0, 500);
  return /^[=+\-@]/.test(s) ? "'" + s : s;
}

function json_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}
